class Recette{
    int[] coutDeConstruction; //tab d'indices des ressources
    int[] quantiteNecessaire;
}