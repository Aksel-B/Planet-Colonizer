class Colon {
    int age;
    int id;
    double sante; //Si sante = 0 alors Mort
    double satisfaction;
    double energie;
    int anneesDerniereNaissance; // Année depuis dernière naissance
}