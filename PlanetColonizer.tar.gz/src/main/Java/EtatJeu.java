class EtatJeu {
    Terrain[] ressources;
    Planete planete;
    Colon[] colons;
    int tour;
    double score;
    Gestion gestion;
    String nom; //nom du fichier de sauvegarde
}
