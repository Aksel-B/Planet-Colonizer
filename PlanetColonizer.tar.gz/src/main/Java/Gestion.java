class Gestion{
    int nombreVivants=6;
    int capaciteTotalePop=15;
    int capaciteEntrepot=400;
    int[][] posBat=new int[729][2];
    int[] variationRessources=new int[11];
    double[] tabMoyennepollution;
    int vaisseauPlace=0;
    int centreDeCommunicationPlace=0;

}