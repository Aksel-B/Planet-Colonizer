import extensions.File;
import extensions.CSVFile;

class PlanetColonizer extends Program{

//-------------------------------------------------------------------FONCTIONS POUR TOUT-------------------------------------------------------------------------------------------------------
    
    // Fonction pour trouver le maximum entre deux entiers
    int max(int a, int b) {
        if (a > b) {
            return a;
        } else {
            return b;
        }
    }

    // Fonction pour trouver le minimum entre deux entiers
    int min(int a, int b) {
        if (a < b) {
            return a;
        } else {
            return b;
        }
    }

    // Fonction pour formater une caractéristique
    String formatCharacteristic(String name, int maxLength) {
        return name + repeatChar(' ', maxLength - length(name));
    }

    // Fonction pour répéter un caractère un certain nombre de fois
    String repeatChar(char ch, int count) {
        String result = "";
        for (int i = 0; i < count; i++) {
            result += ch;
        }
        return result;
    }

    boolean TerrainTabIsEmpty(Terrain[] tab){
        boolean isEmpty=false;
        int nullCmpt=0;
        int id=0;
        while(id<length(tab)){
            if(tab[id]==null){
                nullCmpt++;
            }
            id++;
        }
        if (nullCmpt==length(tab)){
            isEmpty=true;
        }
        return isEmpty;
    }

    // Convertit un entier en caractère (utile pour l'affichage de la carte)
    char IntToChar(int n) {
        String str = "";
        return charAt(str += n, 0); // Transforme l'entier en chaîne, puis retourne le premier caractère
    }

    boolean stringToBoolean(String bool){
        if (equals(bool,"true")){
            return true;
        }
        return false;
    }
    
        // Permet à l'utilisateur de saisir un numéro de ligne valide
    int saisirLigne (int nombreLignes){
        int ligne;
        do {
            ligne = readIntSecurise(ANSI_BOLD + "Saisissez une ligne" + ANSI_RESET + "   (1,2,3,...) : "); // Lire un entier pour la ligne
        } while (ligne < 1 || ligne > nombreLignes-1); // Valide uniquement si dans l'intervalle
        return ligne;
    }


    int saisirColonne(int nombreColonne) {
        int colonne;
        do {
            // Utiliser la nouvelle méthode sécurisée
            char caractere = readCharMajSecurise(ANSI_BOLD + "Saisissez une colonne" + ANSI_RESET + " (A,B,C,...) : ");
            
            // Convertir le caractère en numéro de colonne
            colonne = caractere - 'A' + 1;
        } while (colonne < 1 || colonne > nombreColonne);
        
        return colonne; // Pour correspondre à l'indexation du tableau
    }

    String readStringSecurise(String prompt) {
        String input;
        boolean inputValide = false;
        
        while (!inputValide) {
            try {
                // Afficher le message de prompt
                print(prompt);
                
                // Lire l'entrée utilisateur
                input = readString();
                
                // Vérifier que l'entrée n'est pas nulle
                if (input == null) {
                    println(ANSI_RED+"Erreur : La saisie ne peut pas être nulle. Veuillez réessayer."+ANSI_RESET);
                    continue;
                }
                
                // Vérifier la longueur de l'entrée après suppression des espaces
                int longueurSansBlancs = 0;
                for (int i = 0; i < length(input); i++) {
                    if (charAt(input, i) != ' ') {
                        longueurSansBlancs++;
                    }
                }
                
                // Vérifier que l'entrée n'est pas vide ou composée uniquement d'espaces
                if (longueurSansBlancs == 0) {
                    println(ANSI_RED+"Erreur : La saisie ne peut pas être vide ou composée uniquement d'espaces. Veuillez réessayer."+ANSI_RESET);
                    continue;
                }
                
                inputValide = true;
                return input;
                
            } catch (Exception e) {
                // Gestion des exceptions inattendues
                println(ANSI_RED+"Une erreur est survenue lors de la saisie. Veuillez réessayer."+ANSI_RESET);
            }
        }
        
        // Cette ligne ne devrait jamais être atteinte
        return "";
    }

    int readIntSecurise(String prompt) {
        while (true) {
            try {
                // Utiliser readStringSecurise pour obtenir une entrée valide
                String input = readStringSecurise(prompt);
                
                // Convertir la chaîne en entier
                int valeur = stringToInt(input);
                
                return valeur;
                
            } catch (Exception e) {
                println(ANSI_RED+"Erreur : Veuillez saisir un nombre entier valide."+ANSI_RESET);
            }
        }
    }

    char readCharSecurise(String prompt) {
        while (true) {
            try {
                // Afficher le message de prompt
                print(prompt);
                
                // Lire l'entrée utilisateur
                String input = readString();
                
                // Vérifier que l'entrée n'est pas nulle
                if (input == null) {
                    println(ANSI_RED+"Erreur : La saisie ne peut pas être nulle. Veuillez réessayer."+ANSI_RESET);
                    continue;
                }
                
                // Vérifier que l'entrée est exactement un caractère
                if (length(input) != 1) {
                    println(ANSI_RED+"Erreur : Veuillez saisir exactement un caractère."+ANSI_RESET);
                    continue;
                }
                
                // Retourner le premier (et seul) caractère de l'entrée
                return charAt(input, 0);
                
            } catch (Exception e) {
                // Gestion des exceptions inattendues
                println(ANSI_RED+"Une erreur est survenue lors de la saisie. Veuillez réessayer."+ANSI_RESET);
            }
        }
    }

    char readCharMajSecurise(String prompt) {
        while (true) {
            // Utiliser la méthode de lecture sécurisée
            char caractere = readCharSecurise(prompt);
            
            // Convertir en majuscule manuellement
            if (caractere >= 'a' && caractere <= 'z') {
                caractere -= 32;
            }
            
            // Vérifier si le caractère est une lettre
            if (!((caractere >= 'A' && caractere <= 'Z'))) {
                println(ANSI_RED + ANSI_BOLD + "Erreur : Veuillez saisir une lettre." + ANSI_RESET);
                continue;
            }
            
            return caractere;
        }
    }

//---------------------------------SAUVEGARDE/Chargement----------------------------------------------------------------------------------

    void sauvegarderJeu(EtatJeu etat, String nomFichier) {
        // Préparation du contenu à sauvegarder
        String[][] donneesJeu = new String[1000][]; // Tableau suffisamment grand
        int ligneActuelle = 0;

        //Nom du fichier
        donneesJeu[ligneActuelle]=new String[]{"NomFichier",etat.nom};
        ligneActuelle++;
        // Sauvegarde des informations de base
        donneesJeu[ligneActuelle] = new String[]{"Tour ", ""+ etat.tour};
        ligneActuelle++;
        donneesJeu[ligneActuelle] = new String[]{"Score", "" + etat.score};
        ligneActuelle++;

        // Sauvegarde des ressources
        donneesJeu[ligneActuelle] = new String[]{"Ressources"};
        ligneActuelle++;
        donneesJeu[ligneActuelle] = new String[]{"Nom", "Symbole", "Quantité", "Pollution"};
        ligneActuelle++;
        for (int i = 0; i < length(etat.ressources); i++) {
            donneesJeu[ligneActuelle] = new String[]{
                    etat.ressources[i].nom, 
                    etat.ressources[i].symbole,
                "" + etat.ressources[i].quantite,
                "" + etat.ressources[i].pollutionGeneree};
            ligneActuelle++;
        }

        donneesJeu[ligneActuelle] = new String[]{"Gestion"};
        String posBatiments = "";

        int nombreBatiments = 0;
        for (int l = 0; l < length(etat.gestion.posBat); l++) {
            if (etat.gestion.posBat[l][0] != 0 || etat.gestion.posBat[l][1] != 0) {
                nombreBatiments++;
            }
        }

        if (nombreBatiments > 0) {
            for (int l = 0; l < length(etat.gestion.posBat); l++) {
                if (etat.gestion.posBat[l][0] == 0 && etat.gestion.posBat[l][1] == 0) continue;

                posBatiments += '(';
                posBatiments += etat.gestion.posBat[l][0] + ',' + etat.gestion.posBat[l][1];
                posBatiments += ')';
            }

            donneesJeu[ligneActuelle + 1] = new String[]{
                "" + etat.gestion.nombreVivants,
                "" + etat.gestion.capaciteTotalePop,
                "" + etat.gestion.capaciteEntrepot,
                "" + etat.gestion.vaisseauPlace,
                "" + etat.gestion.centreDeCommunicationPlace,
                posBatiments
            };
            ligneActuelle += 2;
        }

        // Sauvegarde de la planète
        donneesJeu[ligneActuelle] = new String[]{"Planete"};
        ligneActuelle++;
        donneesJeu[ligneActuelle] = new String[]{"Pollution","" + etat.planete.pollution};
        ligneActuelle += 2;

        // Sauvegarde de la carte de la planète
        donneesJeu[ligneActuelle] = new String[]{"Carte"};
        ligneActuelle++;
        donneesJeu[ligneActuelle] = new String[]{"Largeur", "Longueur"};
        donneesJeu[ligneActuelle + 1] = new String[]{
            "" + length(etat.planete.carte, 2), 
            "" + length(etat.planete.carte, 1)
        };
        ligneActuelle += 2;

        // Sauvegarde des bâtiments
        donneesJeu[ligneActuelle] = new String[]{"Batiments"};
        ligneActuelle++;
        donneesJeu[ligneActuelle] = new String[]{"Position Ligne", "Position Colonne", "Nom", "Symbole", "Quantité Générée", "Quantité Consommée", "En Fonctionnement"};
        ligneActuelle++;
        for (int i = 0; i < length(etat.gestion.posBat, 1); i++) {
            int lig = etat.gestion.posBat[i][0];
            int col = etat.gestion.posBat[i][1];
            CaseCarte caseCarte = etat.planete.carte[lig][col];
            
            donneesJeu[ligneActuelle] = new String[]{
                "" + lig,
                "" + col,
                caseCarte.ressourceActuelle.nom,
                caseCarte.ressourceActuelle.symbole,
                "" + (caseCarte.ressourceActuelle.quantiteResGeneree != null ? caseCarte.ressourceActuelle.quantiteResGeneree[0] : 0),
                "" + (caseCarte.ressourceActuelle.quantiteResConso != null ? caseCarte.ressourceActuelle.quantiteResConso[0] : 0),
                "" + caseCarte.ressourceActuelle.fonctionne
            };
            ligneActuelle++;
        }


        // Sauvegarde des colons
        donneesJeu[ligneActuelle] = new String[]{"Colons"};
        ligneActuelle++;
        donneesJeu[ligneActuelle] = new String[]{"ID", "Age", "Santé", "Satisfaction", "Energie", "Années depuis dernière naissance"};
        ligneActuelle++;
        for (int i = 0; i < length(etat.colons); i++) {
            if (etat.colons[i] != null) {
                donneesJeu[ligneActuelle] = new String[]{
                    "" + etat.colons[i].id,
                    "" + etat.colons[i].age,
                    "" + etat.colons[i].sante,
                    "" + etat.colons[i].satisfaction,
                    "" + etat.colons[i].energie,
                    "" + etat.colons[i].anneesDerniereNaissance
                };
                ligneActuelle++;
            }
        }

        // Sauvegarder dans un fichier CSV
        //try {
            saveCSV(donneesJeu, "../save/"+ nomFichier);
            println(ANSI_BOLD + "Jeu sauvegardé avec succès" + ANSI_RESET + " dans " + nomFichier);
        //} catch (Exception e) {
         //   println("Erreur lors de la sauvegarde du jeu : " + e.getMessage());
       // }
    }

     EtatJeu chargerJeu(String nomFichier) {
        EtatJeu etatCharge = new EtatJeu();
        
        try {
            CSVFile fichierSauvegarde = loadCSV(nomFichier);
            
            // Variables temporaires pour reconstruction
            int nombreRessources = 0;
            int nombreColons = 0;
            int largeurCarte = 0;
            int longueurCarte = 0;
            
            // Parcourir le fichier CSV pour extraire les informations
            for (int ligne = 0; ligne < rowCount(fichierSauvegarde); ligne++) {
                String cellule0 = getCell(fichierSauvegarde, ligne, 0);
                
                if (equals(cellule0,"NomFichier")){
                    etatCharge.nom=getCell(fichierSauvegarde,ligne,1);
                }
                // Charger les informations de base
                if (equals(cellule0, "Tour")) {
                    etatCharge.tour = stringToInt(getCell(fichierSauvegarde, ligne , 1));
                }
                
                if (equals(cellule0, "Score")) {
                    etatCharge.score = stringToDouble(getCell(fichierSauvegarde, ligne, 1));
                }
                
                // Charger les ressources
                if (equals(cellule0, "Ressources")) {
                    // Compter le nombre de ressources
                    int i = ligne + 2;
                    while (i < rowCount(fichierSauvegarde) && !equals(getCell(fichierSauvegarde, i, 0), "Planete")) {
                        nombreRessources++;
                        i++;
                    }
                    
                    // Initialiser le tableau de ressources
                    etatCharge.ressources = new Terrain[nombreRessources];
                    
                    // Charger les détails des ressources
                    for (int j = 0; j < nombreRessources; j++) {
                        String[] detailsRessource = new String[4];
                        for (int k = 0; k < 4; k++) {
                            detailsRessource[k] = getCell(fichierSauvegarde, ligne + 2 + j, k);
                        }
                        
                        etatCharge.ressources[j] = newRessource(
                            detailsRessource[0],  // Nom
                            detailsRessource[1],  // Symbole
                            stringToDouble(detailsRessource[2]),  // Probabilité
                            stringToInt(detailsRessource[3])    // Quantité
                        );
                    }
                }

                //Charger les paramètres de Gestion
                if (equals(cellule0, "Gestion")) {
                    etatCharge.gestion.nombreVivants=stringToInt(getCell(fichierSauvegarde,ligne+1,0));
                    etatCharge.gestion.capaciteTotalePop=stringToInt(getCell(fichierSauvegarde,ligne+1,1));
                    etatCharge.gestion.capaciteEntrepot=stringToInt(getCell(fichierSauvegarde,ligne+1,2));
                    etatCharge.gestion.vaisseauPlace=stringToInt(getCell(fichierSauvegarde,ligne+1,3));
                    etatCharge.gestion.centreDeCommunicationPlace=stringToInt(getCell(fichierSauvegarde,ligne+1,4));
                    
                }
                // Charger les informations de la planète
                if (equals(cellule0, "Planete")) {
                    etatCharge.planete.pollution = stringToDouble(getCell(fichierSauvegarde, ligne + 1, 1));
                }
                
                // Charger les dimensions de la carte
                if (equals(cellule0, "Carte")) {
                    largeurCarte = stringToInt(getCell(fichierSauvegarde, ligne + 2, 1));
                    longueurCarte = stringToInt(getCell(fichierSauvegarde, ligne + 2, 2));
                    
                    // Créer la nouvelle planète avec les bonnes dimensions
                    etatCharge.planete = newPlanete(etatCharge.ressources, longueurCarte, largeurCarte);
                }
                
                // Charger le contenu de la carte
                if (equals(cellule0, "Contenu de la Carte")) {
                    int i = ligne + 1;
                    while (i < rowCount(fichierSauvegarde) && !equals(getCell(fichierSauvegarde, i, 0), "Colons")) {
                        int l = stringToInt(getCell(fichierSauvegarde, i, 0));
                        int c = stringToInt(getCell(fichierSauvegarde, i, 1));

                        String symbole = getCell(fichierSauvegarde, i, 2); // Symbole de la case
                        int quantiteRestante = stringToInt(getCell(fichierSauvegarde, i, 3)); // Quantité de ressource restante
                        boolean exploitee = stringToBoolean(getCell(fichierSauvegarde, i, 4)); // Case exploitée
            
                        String ressourceActuelleNom = getCell(fichierSauvegarde, i, 5); // Nom du terrain actuel
                        String ressourceCaseInitNom = getCell(fichierSauvegarde, i, 6); // Nom de la ressource initiale

                        Terrain ressourceActuelle = null;
                        for (Terrain terrain : etatCharge.ressources) {
                            if (equals(terrain.nom, ressourceActuelleNom)) {
                                ressourceActuelle = terrain;
                            }
                            break;
                        }

                        // Récupérer la ressource initiale correspondant au nom
                        Terrain ressourceCaseInit = null;
                        for (Terrain terrain : etatCharge.ressources) {
                            if (equals(terrain.nom, ressourceCaseInitNom)) {
                                ressourceCaseInit = terrain;
                            }
                            break;
                        }                                                  
                        
                        etatCharge.planete.carte[l][c] = newCaseCarte(ressourceActuelle, quantiteRestante, ressourceCaseInit,exploitee);
                        i++;
                    }
                }

                if (equals(cellule0, "Batiments")) {
                    int i = ligne + 2;
                    while (i < rowCount(fichierSauvegarde) && !equals(getCell(fichierSauvegarde, i, 0), "Colons")) {
                        int lig = stringToInt(getCell(fichierSauvegarde, i, 0));
                        int col = stringToInt(getCell(fichierSauvegarde, i, 1));
                        String nom = getCell(fichierSauvegarde, i, 2);
                        String symbole = getCell(fichierSauvegarde, i, 3);
                        int quantiteGeneree = stringToInt(getCell(fichierSauvegarde, i, 4));
                        int quantiteConsommee = stringToInt(getCell(fichierSauvegarde, i, 5));
                        boolean fonctionne = stringToBoolean(getCell(fichierSauvegarde, i, 6));
                        
                        // Trouver le bâtiment correspondant
                        Terrain batiment = null;
                        for (Terrain b : LISTEBATIMENTSPOSSIBLES) {
                            if (equals(b.nom, nom)) {
                                batiment = b;
                                break;
                            }
                        }
                        
                        if (batiment != null) {
                            etatCharge.planete.carte[lig][col] = newCaseCarte(batiment, -1, batiment,true); // Remet à jour la case avec le bâtiment
                            etatCharge.planete.carte[lig][col].ressourceActuelle.fonctionne = fonctionne;
                        }
                        i++;
                    }
                }

                
                // Charger les colons
                if (equals(cellule0, "Colons")) {
                    // Compter le nombre de colons
                    int i = ligne + 2;
                    while (i < rowCount(fichierSauvegarde) && i < ligne + 100) {
                        nombreColons++;
                        i++;
                    }
                    
                    // Initialiser le tableau de colons
                    etatCharge.colons = new Colon[nombreColons];
                    
                    // Charger les détails des colons
                    for (int j = 0; j < nombreColons; j++) {
                        Colon colon = new Colon();
                        colon.id = stringToInt(getCell(fichierSauvegarde, ligne + 2 + j, 0));
                        colon.age = stringToInt(getCell(fichierSauvegarde, ligne + 2 + j, 1));
                        colon.sante = stringToDouble(getCell(fichierSauvegarde, ligne + 2 + j, 2));
                        colon.satisfaction = stringToDouble(getCell(fichierSauvegarde, ligne + 2 + j, 3));
                        colon.energie = stringToDouble(getCell(fichierSauvegarde, ligne + 2 + j, 4));
                        colon.anneesDerniereNaissance = stringToInt(getCell(fichierSauvegarde, ligne + 2 + j, 5));
                        
                        etatCharge.colons[j] = colon;
                    }
                }
            }
            
            println("Jeu chargé avec succès depuis " + nomFichier);
            return etatCharge;
            
        } catch (Exception e) {
            println("Erreur lors du chargement du jeu : " + e.getMessage());
            return null;
        }
    } 

//---------------------------------RESSOURCES-------------------------------------------------------------------------------------

    final Terrain[] RESSOURCESINIT=new Terrain[]{ 
                        //Nom,Symbole,probaApparition,quantite
            newRessource("Terre", " + ", 1.0, 0), // Ressource par défaut
            newRessource("Terre", " + ", 0.200, 0),
            newRessource("Fer", "Fe ", 0.100, 100), 
            newRessource("Cuivre", "Cu ", 0.075, 50),
            newRessource("Carbone", " C ", 0.050, 35),
            newRessource("Sulfure", " S ", 0.025, 10),
            newRessource("☢ Plutonium", "Pu ", 0.0005, 5), // Ressource rare et polluante
            newRessource("💧 Eau", "H2O", 1.0, 100), // Ressources essentielles
            newRessource("💨 Air", "O2", 1.0, 50), 
            newRessource("🍎 Nourriture", "Rations", 1.0, 50),

            newRessource("⚡ Electricité", "Elec",1.0,150)
        };

    // Fonction pour créer une nouvelle ressource avec des attributs spécifiques
    Terrain newRessource(String nom, String symbole, double probaApparition, int quantite) {
        Terrain r = new Terrain();
        r.nom = nom; // Nom de la ressource
        r.symbole = symbole; // Symbole représentant la ressource
        r.probaApparition = probaApparition; // Probabilité d'apparition de la ressource
        r.quantite = quantite; // Quantité initiale de la ressource
        
        return r; // Retourne une instance de la ressource
    }

    String getResourceColor(String ressource,CaseCarte caseC) {
        switch (ressource) {
            // Ressources initiales
            case " + ":
                return ANSI_WHITE + ANSI_DARK_BG;
            case "Fe ":
                return ANSI_RED + ANSI_DARK_BG;
            case "Cu ":
                return ANSI_ORANGE + ANSI_DARK_BG;
            case " C ":
                return ANSI_GREEN + ANSI_DARK_BG;
            case " S ":
                return ANSI_BLUE + ANSI_DARK_BG;
            case "Pu ":
                return ANSI_PURPLE + ANSI_DARK_BG;
            
            // Bâtiments
            case " V ":  // Vaisseau
                return ANSI_GREENKINDOF + ANSI_DARK_BG;
            case " ⌂ ":  // Dortoir
                return ANSI_BROWN + ANSI_DARK_BG;
            case " ⌧ ":  // Entrepôt
                return ANSI_GRAY + ANSI_DARK_BG;
            case " ☤ ":  // Centre de Communication Terrien
                return ANSI_MAGENTA + ANSI_DARK_BG;
            case " ◈ ":  // Cinema
                return ANSI_YELLOW + ANSI_DARK_BG;
            case " ⌯ ":  // Capteur d'Humidité
                return ANSI_BLUE_LIGHT + ANSI_DARK_BG;
            case " ✲ ":  // Ferme hydroponique
                return ANSI_GREEN_LIGHT + ANSI_DARK_BG;
            case " ≎ ":  // Recycleur d'Air
                return ANSI_CYAN_LIGHT + ANSI_DARK_BG;
            case " ☼ ":  // Panneau Stellaire
                return ANSI_YELLOW_BRIGHT + ANSI_DARK_BG;
            case " ☢ ":  // Centrale nucléaire
                return ANSI_RED_BRIGHT + ANSI_DARK_BG;
            case " ⍒ ":  // Puit de Forage
                return getResourceColor(caseC.ressourceCaseInit.symbole,caseC);
            
            default:
                return ANSI_RESET;
        }
    }

    final String ANSI_MAGENTA = "\033[35m";
    final String ANSI_ORANGE = "\033[38;2;255;165;0m";
    final String ANSI_GREENKINDOF = "\033[38;5;42m";
    final String ANSI_DARK_BG = "\033[48;2;52;40;61m";
    final String ANSI_BROWN = "\033[38;2;139;69;19m";
    final String ANSI_GRAY = "\033[38;2;128;128;128m";
    final String ANSI_BLUE_LIGHT = "\033[38;2;173;216;230m";
    final String ANSI_GREEN_LIGHT = "\033[38;2;144;238;144m";
    final String ANSI_CYAN_LIGHT = "\033[38;2;224;255;255m";
    final String ANSI_YELLOW_BRIGHT = "\033[38;2;255;255;0m";
    final String ANSI_RED_BRIGHT = "\033[38;2;255;0;0m";
    final String ANSI_ORANGE_DARK = "\033[38;2;255;140;0m";

//----------------------------------------BATIMENTS------------------------------------------------------------------------------------------------------------------------
    
    final Terrain[] LISTEBATIMENTSPOSSIBLES=new Terrain[]{
                  //Recette ResNecessaire, String nom,String symbole,,double pollutionGeneree,int[] ressourcesConso, int[] quantiteResConso,int[] ressourcesGeneree, int[] quantiteResGeneree
        newBatiment(newRecette(),"Vaisseau"," V ",0.0001,new int[]{10},new int[]{150},new int[]{10},new int[]{150}),

        newBatiment(newRecette(new int[]{2,3},new int[]{5,10}),"Dortoir"," ⌂ ",0.0005,new int[]{10},new int[]{10},new int[]{-1},new int[]{0}),
        newBatiment(newRecette(new int[]{2},new int[]{15}),"Entrepôt"," ⌧ ",0.0002,new int[]{10},new int[]{5},new int[]{-1},new int[]{0}),
        newBatiment(newRecette(new int[]{2,3,4},new int[]{125,35,30}),"Centre de Communication Terrien"," ☤ ",0.0007,new int[]{10},new int[]{35},new int[]{-1},new int[]{0}),
        newBatiment(newRecette(new int[]{2,3,4},new int[]{75,25,10}),"Cinema"," ◈ ",0.0007,new int[]{10},new int[]{50},new int[]{-1},new int[]{0}),
        
        newBatiment(newRecette(new int[]{2,3,5},new int[]{5,10,5}),"Capteur d'Humidité"," ⌯ ",0.0001,new int[]{10}, new int[]{20},new int[]{7}, new int[]{10}),
        newBatiment(newRecette(new int[]{2,4,7},new int[]{5,5,5}),"Ferme hydroponique"," ✲ ",-0.0005,new int[]{7,10},new int[]{10,20},new int[]{8,9},new int[]{5,10}), //10 rations 5 O2
        newBatiment(newRecette(new int[]{3,7},new int[]{5,5}),"Recycleur d'Air"," ≎ ",0.0001,new int[]{10}, new int[]{20},new int[]{8}, new int[]{10}),

        newBatiment(newRecette(new int[]{3,5},new int[]{5,10}),"Panneau Stellaire"," ☼ ",0.0001,new int[]{10}, new int[]{0},new int[]{10},new int[]{20}),
        newBatiment(newRecette(new int[]{2,6,7},new int[]{100,5,30}),"Centrale nucléaire"," ☢ ",0.0001,new int[]{6,7,10},new int[]{2,10,100},new int[]{10},new int[]{400}),//Conso 5 Pu 10 H2O

        newBatiment(newRecette(new int[]{2,3,4},new int[]{10,5,5}),"Puit de Forage"," ⍒ ",0.005,new int[]{0,10},new int[]{0,25},new int[1],new int[1]) //Prod/Conso variable selon la ressource
    };

    // Si on veut faire des ressources plus complexes et modifier les recettes en conséquence
    //newBatiment(newRecette(new Terrain[]{RESSOURCESINIT[2],RESSOURCESINIT[3],RESSOURCESINIT[4]},new int[]{75,25,10}),"Usine de Transformation"," ⌬ ",0.001,25,new int[1],new int[1]), //Prod/Conso variable selon la ressource


    Recette newRecette(){
        Recette r=new Recette();
        r.coutDeConstruction=new int[0];
        return r;
    }
    
    Recette newRecette(int[] ressources,int[] quantiteNecessaire){
        Recette r=new Recette ();
        r.coutDeConstruction=ressources;
        r.quantiteNecessaire=quantiteNecessaire;
        return r;
    }
    
    Terrain newBatiment(Recette ResNecessaire, String nom,String symbole,double pollutionGeneree,int[] ressourcesConso, int[] quantiteResConso,int[] ressourcesGeneree, int[] quantiteResGeneree){
        Terrain b=new Terrain();
        b.ResNecessaire=ResNecessaire;
        b.ressourcesGeneree=ressourcesGeneree;
        b.quantiteResGeneree=quantiteResGeneree;
        b.ressourcesConso=ressourcesConso;
        b.quantiteResConso=quantiteResConso;
        b.pollutionGeneree=pollutionGeneree;

        b.nom=nom;
        b.symbole=symbole;
        return b;
    }

    int placerBatiment(EtatJeu etat, Terrain[] LISTEBATIMENTSPOSSIBLES,int lig,int col,Terrain batiment){
        etat.gestion.posBat[countLastPos(etat.gestion.posBat)]=new int[]{lig,col};
        int id=0;
        while(id<length(LISTEBATIMENTSPOSSIBLES) && batiment!=LISTEBATIMENTSPOSSIBLES[id]){
            id++;
        }
        if(batiment==LISTEBATIMENTSPOSSIBLES[0]){// Vaisseau
            etat.planete.carte[lig][col]=newCaseCarte(batiment,-1,batiment,true); //-1 car ressource inépuisable
            etat.gestion.vaisseauPlace=1;
            return etat.gestion.vaisseauPlace;

        }else if(batiment==LISTEBATIMENTSPOSSIBLES[1]){ //Dortoirs
            etat.planete.carte[lig][col]=newCaseCarte(batiment,-1,batiment,true);
            etat.gestion.capaciteTotalePop+=15;
            return etat.gestion.capaciteTotalePop;

        }else if(batiment==LISTEBATIMENTSPOSSIBLES[2]){ //Entrepots
            etat.planete.carte[lig][col]=newCaseCarte(batiment,-1,batiment,true);
            etat.gestion.capaciteEntrepot+=150;
            return etat.gestion.capaciteEntrepot;

        }else if(batiment==LISTEBATIMENTSPOSSIBLES[3]){ //Centre de Communication Terrien
            etat.planete.carte[lig][col]=newCaseCarte(batiment,-1,batiment,true);
            etat.gestion.centreDeCommunicationPlace=1;
            return etat.gestion.centreDeCommunicationPlace;

        }else if(id < 10){
            etat.planete.carte[lig][col]=newCaseCarte(batiment,-1,batiment,true);
        }else{
            if(etat.planete.carte[lig][col].ressourceCaseInit.nom==etat.ressources[2].nom){ //Fer
                etat.planete.carte[lig][col]=newCaseCarte(batiment,500,etat.planete.carte[lig][col].ressourceCaseInit,true);
                etat.planete.carte[lig][col].ressourceActuelle.ressourcesConso[0]=2;
                etat.planete.carte[lig][col].ressourceActuelle.quantiteResConso[0]=10;
                etat.planete.carte[lig][col].ressourceActuelle.ressourcesGeneree[0]=2;
                etat.planete.carte[lig][col].ressourceActuelle.quantiteResGeneree[0]=10; 

            }else if(etat.planete.carte[lig][col].ressourceCaseInit.nom==etat.ressources[3].nom){ //Cuivre
                etat.planete.carte[lig][col]=newCaseCarte(batiment,500,etat.planete.carte[lig][col].ressourceCaseInit,true);
                etat.planete.carte[lig][col].ressourceActuelle.ressourcesConso[0]=3;
                etat.planete.carte[lig][col].ressourceActuelle.quantiteResConso[0]=12;
                etat.planete.carte[lig][col].ressourceActuelle.ressourcesGeneree[0]=3;
                etat.planete.carte[lig][col].ressourceActuelle.quantiteResGeneree[0]=7;

            }else if(etat.planete.carte[lig][col].ressourceCaseInit.nom==etat.ressources[4].nom){ //Carbone
                etat.planete.carte[lig][col]=newCaseCarte(batiment,400,etat.planete.carte[lig][col].ressourceCaseInit,true);
                etat.planete.carte[lig][col].ressourceActuelle.ressourcesConso[0]=4;
                etat.planete.carte[lig][col].ressourceActuelle.quantiteResConso[0]=15;
                etat.planete.carte[lig][col].ressourceActuelle.ressourcesGeneree[0]=4;
                etat.planete.carte[lig][col].ressourceActuelle.quantiteResGeneree[0]=5;

            }else if(etat.planete.carte[lig][col].ressourceCaseInit.nom==etat.ressources[5].nom){ //Sulfure
                etat.planete.carte[lig][col]=newCaseCarte(batiment,300,etat.planete.carte[lig][col].ressourceCaseInit,true);
                etat.planete.carte[lig][col].ressourceActuelle.ressourcesConso[0]=5;
                etat.planete.carte[lig][col].ressourceActuelle.quantiteResConso[0]=15;
                etat.planete.carte[lig][col].ressourceActuelle.ressourcesGeneree[0]=5;
                etat.planete.carte[lig][col].ressourceActuelle.quantiteResGeneree[0]=5;

            }else if(etat.planete.carte[lig][col].ressourceCaseInit.nom==etat.ressources[6].nom){ //Plutonium
                etat.planete.carte[lig][col]=newCaseCarte(batiment,200,etat.planete.carte[lig][col].ressourceCaseInit,true);
                etat.planete.carte[lig][col].ressourceActuelle.ressourcesConso[0]=6;
                etat.planete.carte[lig][col].ressourceActuelle.quantiteResConso[0]=15;
                etat.planete.carte[lig][col].ressourceActuelle.ressourcesGeneree[0]=6;
                etat.planete.carte[lig][col].ressourceActuelle.quantiteResGeneree[0]=1;
            }
        }
        for (int i=0;i<length(batiment.ResNecessaire.coutDeConstruction);i++){
            int idRes=batiment.ResNecessaire.coutDeConstruction[i];
            etat.ressources[idRes].quantite-=batiment.ResNecessaire.quantiteNecessaire[i];
            etat.gestion.variationRessources[idRes]-=batiment.ResNecessaire.quantiteNecessaire[i];
        }
        return id;
    }

    // Repère la dernière position enregistrée d'un batiment
    int countLastPos(int[][] posBat){      
        int id=0;
        while(id < length(posBat) && posBat[id][0]!=0){
            id++;
        }
        return id;
    }

    boolean batimentPosable(EtatJeu etat, Terrain[] LISTEBATIMENTSPOSSIBLES,int lig, int col, Terrain batiment){
        boolean posableTerrain=true;
        boolean posableRessource=true;

        if((etat.planete.carte[lig][col].ressourceCaseInit==etat.ressources[0] || etat.planete.carte[lig][col].ressourceCaseInit==etat.ressources[1]) && equals(batiment.nom,LISTEBATIMENTSPOSSIBLES[10].nom)){
            posableTerrain=false;
        }
        int id=0;
        while(id<length(etat.ressources) && etat.planete.carte[lig][col].ressourceCaseInit!=etat.ressources[id]){
            id++;
        }
        if(!equals(batiment.nom,LISTEBATIMENTSPOSSIBLES[10].nom) && (id>=2 && id<7)){
            posableTerrain=false;
        }
        if((batiment==LISTEBATIMENTSPOSSIBLES[3] && etat.gestion.centreDeCommunicationPlace==1) || (batiment==LISTEBATIMENTSPOSSIBLES[0] && etat.gestion.vaisseauPlace==1)){
            posableTerrain=false;
        }
        id=0;
        while(id<length(batiment.ResNecessaire.coutDeConstruction) && posableRessource){
            int idRes=batiment.ResNecessaire.coutDeConstruction[id];
            if(batiment.ResNecessaire.quantiteNecessaire[id]>etat.ressources[idRes].quantite){
                posableRessource=false;
            }
            id++;
        }

        return (posableTerrain==true && posableRessource==true && etat.planete.carte[lig][col].exploitee==false) ? true:false;
    }

    void mettreAJourBatiment(EtatJeu etat, Terrain[] LISTEBATIMENTSPOSSIBLES){
        int capaciteEntreposee=0;
        for(int i=0;i<length(etat.ressources)-1;i++){       // L'electricite n'est pas comprise dans le stockage
            capaciteEntreposee+=etat.ressources[i].quantite;
        }

        for(int i=0;i<countLastPos(etat.gestion.posBat);i++){
            CaseCarte batiment=etat.planete.carte[etat.gestion.posBat[i][0]][etat.gestion.posBat[i][1]];

            if (capaciteEntreposee<etat.gestion.capaciteEntrepot && batiment.ressourceActuelle.fonctionne==false){
                marcheArret(LISTEBATIMENTSPOSSIBLES,etat.planete.carte,etat.gestion.posBat[i][0],etat.gestion.posBat[i][1]);
            }

            if (batiment.ressourceActuelle.fonctionne==true){
                if(equals(batiment.ressourceActuelle.nom,LISTEBATIMENTSPOSSIBLES[10].nom)){
                    mettreAJourPuitDeForage(etat,LISTEBATIMENTSPOSSIBLES,etat.gestion.posBat[i][0],etat.gestion.posBat[i][1],capaciteEntreposee,i);
                }else{
                    int id=0;
                    while(id < length(LISTEBATIMENTSPOSSIBLES) && !equals(batiment.ressourceActuelle.nom,LISTEBATIMENTSPOSSIBLES[id].nom)){
                        id++;
                    }
                    if(batiment.ressourceActuelle.ressourcesGeneree[0] !=-1){ //Si le batiment genere quelque chose
                        boolean peutConsommerRes=true;
                        int cmpt=0;
                        int idRes=0;
                        while(cmpt<length(batiment.ressourceActuelle.ressourcesConso) && peutConsommerRes!=false){
                            idRes=batiment.ressourceActuelle.ressourcesConso[cmpt];
                            if(((etat.ressources[idRes].quantite)-batiment.ressourceActuelle.quantiteResConso[cmpt])<0){
                                peutConsommerRes=false;
                            }
                            cmpt++;
                        }
                        if (peutConsommerRes){
                            etat.gestion.tabMoyennepollution[id]+=batiment.ressourceActuelle.pollutionGeneree;

                            consommer(etat,etat.gestion.posBat[i][0],etat.gestion.posBat[i][1]);

                            generer(etat,LISTEBATIMENTSPOSSIBLES,etat.gestion.posBat[i][0],etat.gestion.posBat[i][1],capaciteEntreposee);
                            
                        }else{
                            //ajout d'un evenement lorsqu'un la ressource est epuisee
                        }
                    }   
                }   
            }
        }
    }
    

    void mettreAJourPuitDeForage(EtatJeu etat, Terrain[] LISTEBATIMENTSPOSSIBLES,int lig, int col, int capaciteEntreposee, int i){
        CaseCarte batiment=etat.planete.carte[lig][col];
        int id=0;
        while(id < length(etat.ressources) && batiment.ressourceCaseInit!=etat.ressources[id]){
            id++;
        }
        if(batiment.quantiteRestante>0 && (batiment.ressourceActuelle.quantiteResGeneree[0]+capaciteEntreposee)<=etat.gestion.capaciteEntrepot){
            batiment.quantiteRestante-=batiment.ressourceActuelle.quantiteResConso[0];
            etat.ressources[id].quantite+=batiment.ressourceActuelle.quantiteResGeneree[0];
            etat.ressources[10].quantite-=batiment.ressourceActuelle.quantiteResConso[1];
            etat.gestion.variationRessources[id]+=batiment.ressourceActuelle.quantiteResGeneree[0];
            etat.gestion.variationRessources[10]-=batiment.ressourceActuelle.quantiteResConso[1];

            etat.gestion.tabMoyennepollution[10]+=batiment.ressourceActuelle.pollutionGeneree;

        }else if(batiment.quantiteRestante<=0){
            marcheArret(LISTEBATIMENTSPOSSIBLES,etat.planete.carte,lig,col);
            //ajout d'un evenement lorsqu'un filon est epuisé
        }else if((batiment.ressourceActuelle.quantiteResGeneree[0]+capaciteEntreposee)>etat.gestion.capaciteEntrepot){
            batiment.quantiteRestante-=etat.gestion.capaciteEntrepot-capaciteEntreposee;
            etat.ressources[id].quantite+=etat.gestion.capaciteEntrepot-capaciteEntreposee;
            etat.ressources[10].quantite-=batiment.ressourceActuelle.quantiteResGeneree[1];
            etat.gestion.variationRessources[id]+=etat.gestion.capaciteEntrepot-capaciteEntreposee;
            etat.gestion.variationRessources[10]-=batiment.ressourceActuelle.quantiteResGeneree[1];

            marcheArret(LISTEBATIMENTSPOSSIBLES,etat.planete.carte,lig,col);

            etat.gestion.tabMoyennepollution[10]+=batiment.ressourceActuelle.pollutionGeneree;
            // ajout d'un evenement lorsque les entrepots sont pleins
        }
    }

    void consommer(EtatJeu etat,int lig, int col){
        CaseCarte batiment=etat.planete.carte[lig][col];
        for(int e=0;e<length(batiment.ressourceActuelle.quantiteResConso);e++){
            int idRes=batiment.ressourceActuelle.ressourcesConso[e];
            etat.ressources[idRes].quantite-=batiment.ressourceActuelle.quantiteResConso[e];
            etat.gestion.variationRessources[idRes]-=batiment.ressourceActuelle.quantiteResConso[e];
        }
    }

    void generer(EtatJeu etat,Terrain[] LISTEBATIMENTSPOSSIBLES,int lig, int col, int capaciteEntreposee){
        CaseCarte batiment=etat.planete.carte[lig][col];
        for(int f=0;f<length(batiment.ressourceActuelle.quantiteResGeneree);f++){
        int idRes=batiment.ressourceActuelle.ressourcesGeneree[f];
            if(((batiment.ressourceActuelle.quantiteResGeneree[f]+capaciteEntreposee)<etat.gestion.capaciteEntrepot && batiment.ressourceActuelle.fonctionne) || batiment.ressourceActuelle.ressourcesGeneree[f]==10){// L'electricite n'est pas comprise dans le stockage
                etat.ressources[idRes].quantite+=batiment.ressourceActuelle.quantiteResGeneree[f];
                etat.gestion.variationRessources[idRes]+=batiment.ressourceActuelle.quantiteResGeneree[f];
            }else{
                etat.ressources[idRes].quantite+=etat.gestion.capaciteEntrepot-capaciteEntreposee;
                etat.gestion.variationRessources[idRes]+=etat.gestion.capaciteEntrepot-capaciteEntreposee;
                marcheArret(LISTEBATIMENTSPOSSIBLES,etat.planete.carte,lig,col);
                // ajout d'un evenement lorsque les entrepots sont pleins
            }
        }
    }

    void marcheArret(Terrain[] LISTEBATIMENTSPOSSIBLES,CaseCarte[][] carte,int lig, int col){
        CaseCarte batiment=carte[lig][col];
        int id=0;
        while(id < length(LISTEBATIMENTSPOSSIBLES) && !equals(batiment.ressourceActuelle.nom,LISTEBATIMENTSPOSSIBLES[id].nom)){
            id++;
        }
        if (batiment.ressourceActuelle.fonctionne==true){
            batiment.ressourceActuelle.quantiteResConso=new int[0];
            batiment.ressourceActuelle.quantiteResGeneree=new int[0];
            batiment.ressourceActuelle.fonctionne=false;
        }else{
            batiment.ressourceActuelle.quantiteResConso=LISTEBATIMENTSPOSSIBLES[id].quantiteResConso;
            batiment.ressourceActuelle.quantiteResGeneree=LISTEBATIMENTSPOSSIBLES[id].quantiteResGeneree;
            batiment.ressourceActuelle.fonctionne=true;
        }
    }


//-------------------------------------------------PLANETE---------------------------------------------------------------------------------------

    // Fonction pour créer une nouvelle planète avec une carte et des ressources
    Planete newPlanete(Terrain[] ressources, int longueur, int largeur) {
        Planete planete = new Planete();
        planete.pollution = 0.0; // Initialisation du niveau de pollution à 0

        // Création de la carte de la planète avec des dimensions spécifiques
        planete.carte = new CaseCarte[largeur][longueur];
        init(planete, ressources); // Initialisation de la carte avec les ressources

        return planete; // Retourne l'objet planète
    }

    CaseCarte newCaseCarte(Terrain ressourceActuelle, int quantiteRestante, Terrain ressourceCaseInit,boolean exploitee){
        CaseCarte c = new CaseCarte();
        c.ressourceActuelle=ressourceActuelle;
        c.ressourceCaseInit=ressourceCaseInit;
        c.exploitee=exploitee;

        c.symbole=ressourceActuelle.symbole;
        c.quantiteRestante=quantiteRestante;
        return c;
    }

    // Fonction pour trouver l'indice de la ressource correspondant à une probabilité donnée
    int encadrement(Terrain[] ressources, double random) {
        int randomAbs = -1; 
        int i = 0;

        // Parcourt les ressources pour trouver l'intervalle correspondant
        while (randomAbs == -1) {
            if (ressources[i].probaApparition <= random) {
                randomAbs = i; // Indice trouvé
            }
            i += 1;
        }

        // Calcul de la différence pour ajuster l'indice si nécessaire
        double diffSup = (ressources[randomAbs - 1].probaApparition - random) ;
        double diffInf = random - ressources[randomAbs].probaApparition;

        if (randomAbs > 0 && diffSup < diffInf) {
            randomAbs -=1;
        }

        return randomAbs; // Retourne l'indice correspondant
    }

    // Initialise la carte de la planète avec des ressources naturelles
    void init(Planete planete, Terrain[] RESSOURCESINIT) {
        for (int l = 0; l < length(planete.carte, 1); l++) {
            for (int c = 0; c < length(planete.carte, 2); c++) {
                double random = (double)(int)(random() * 1000) / 1000; // Génération d'une probabilité aléatoire
                if (random == 0.0000) {
                    random += 0.0005; // Correction pour éviter une valeur nulle
                }
                // Assignation d'une ressource à la case en fonction de la probabilité
                int IDRessource=encadrement(RESSOURCESINIT, random);
                planete.carte[l][c] = newCaseCarte(RESSOURCESINIT[IDRessource],500,RESSOURCESINIT[IDRessource],false);
            }
        }
    }

    double pollutionTotale(double pollutionPlanete, double[] tabMoyennepollution){
        double pollutionTotale=0.0;
        for (int i=2;i<length(tabMoyennepollution);i++){
            pollutionTotale+=tabMoyennepollution[i];
            if (tabMoyennepollution[i]!=0){
                println(i);
            }
        }
        return (pollutionTotale/length(tabMoyennepollution)-2)+pollutionPlanete;
    }

//-------------------------------------------COLONS----------------------------------------------------------------------------------

    final int AGE_REPRODUCTION_MIN = 20; // Âge minimum pour la reproduction
    final int AGE_REPRODUCTION_MAX = 50; // Âge maximum pour la reproduction
    final double PROBABILITE_REPRODUCTION = 0.1; // Probabilité qu'un colon puisse se reproduire

    // Fonction pour créer un nouveau colon avec des caractéristiques aléatoires
    Colon newColon(int age, int id) {
        Colon colon = new Colon();
        
        colon.age = age; // Âge du colon
        colon.id = id; // Identifiant unique du colon
        colon.sante=1.0;
        colon.satisfaction = 1.0; // Satisfaction initiale du colon
        colon.energie = 1.0; // Énergie initiale du colon
        colon.anneesDerniereNaissance = 0; // Années écoulées depuis la dernière naissance

        return colon; // Retourne une instance de colon
    }

    Colon[] genererColons(int nombreColons) {
        Colon[] colons = new Colon[nombreColons];
        
        for (int i = 0; i < nombreColons; i++) {
            // Générer un âge aléatoire entre 20 et 40 ans
            int age = 20 + (int)(random() * 21);
            
            // Créer un nouveau colon avec un âge et un identifiant unique
            colons[i] = newColon(age, i + 1);
        }
        
        return colons;
    }

    // Fonction pour permettre aux colons de se reproduire
    Colon[] reproduire(Colon[] colons,Gestion gestion) {
        // Trouver deux colons éligibles pour la reproduction
        Colon[] parents;
        if (gestion.capaciteTotalePop>gestion.nombreVivants){
            parents = trouverParentsEligibles(colons,gestion);
        }else{
            return colons;
        }
        if (parents[0]==null || parents[1]==null){
            return colons;
        }else{
            // Générer un nouvel enfant à partir des deux parents
            Colon nouvelEnfant = newColon(0, trouverProchainId(colons));// genère un enfant
        
            // Ajouter l'enfant à la liste des colons
            colons[gestion.nombreVivants] = nouvelEnfant; // Ajouter l'enfant à l'emplacement disponible
            println(ANSI_BOLD + "Nouvelle naissance ! " +ANSI_RESET+ "Colon N°" + nouvelEnfant.id + 
                        " (Enfant de N°" + parents[0].id + " et N°" + parents[1].id + ")");
        
        
        
            // Réinitialiser le compteur d'années depuis la dernière naissance pour les parents
            parents[0].anneesDerniereNaissance = 0;
            parents[1].anneesDerniereNaissance = 0;
        
            return colons; // Retourner la liste des colons mise à jour
        }
    }

    // Fonction pour trouver deux colons éligibles pour la reproduction
    Colon[] trouverParentsEligibles(Colon[] colons,Gestion gestion) {
        Colon[] parents = new Colon[2];
        boolean mereTrouvee=false,pereTrouve=false;
        
        int cmpt=0;
        while(cmpt < length(colons) && (!mereTrouvee || !pereTrouve) && colons[cmpt]!=null) { 
            // Vérifier les conditions de reproduction
            boolean conditionsReproduction = (
                colons[cmpt].age >= AGE_REPRODUCTION_MIN && 
                colons[cmpt].age <= AGE_REPRODUCTION_MAX &&
                colons[cmpt].sante > 0.5 &&
                colons[cmpt].anneesDerniereNaissance >= 2
            );
            
            // Assigner le colon comme mâle ou femelle s'il remplit les conditions
            if (conditionsReproduction) {
                if (colons[cmpt].id%2==1 && mereTrouvee == false) {
                    parents[0] = colons[cmpt];
                    mereTrouvee=true;
                } else if (colons[cmpt].id%2==0 && pereTrouve == false) {
                    parents[1] = colons[cmpt];
                    pereTrouve=true;
                }
            }
            
            cmpt++;
        }
        return parents; // Retourner le couple de parents éligibles
    }

    // Fonction pour trouver le prochain identifiant unique pour un colon
    int trouverProchainId(Colon[] colons) {
        int cmpt=0;
        while(colons[cmpt]!=null && cmpt<length(colons)){
            cmpt++;
        } //
        return colons[cmpt-1].id+1; // Retourner l'ID suivant
    }

    // Fonction pour vieillir un colon
    void vieillir(EtatJeu etat,int id) {
        boolean estMort=false;
        etat.colons[id].age++; // Augmenter l'âge
 
        if(etat.colons[id].age<=20){ // Diminuer la santé
            etat.colons[id].sante-=0.02;
        }else if (etat.colons[id].age<=45){
            etat.colons[id].sante -= 0.05;
        }else{
            etat.colons[id].sante-=0.10;
        }
        // Si la santé tombe à 0 ou moins, le colon meurt
        if (etat.colons[id].sante <= 0.0) {
            println("☠ Le colon N°" + etat.colons[id].id + " est "+ ANSI_BOLD + "décédé" + ANSI_RESET + " à l'âge de " + etat.colons[id].age + ".");
            etat.colons[id]=null;
            estMort=true;
        }else{
            if (etat.ressources[8].quantite==0){ //Si Air=0 alors le colon meurt
                etat.colons[id].sante-=1.0;
            }else{
                etat.ressources[8].quantite-=1;
                etat.gestion.variationRessources[8]-=1;
            }

            if (etat.ressources[7].quantite==0 || etat.ressources[9].quantite==0){
                etat.colons[id].sante-=0.20;
            }
            if(etat.ressources[7].quantite!=0){
                etat.ressources[7].quantite-=1;
                etat.gestion.variationRessources[7]-=1;
            }
            if(etat.ressources[9].quantite!=0){
                etat.ressources[9].quantite-=1;
                etat.gestion.variationRessources[9]-=1;
            }
        }
        // Si la santé tombe à 0 ou moins, le colon meurt
        if (!estMort){
            if (etat.colons[id].sante <= 0.0) {
                println("☠ Le colon N°" + etat.colons[id].id + " est "+ ANSI_BOLD + "décédé" + ANSI_RESET + " à l'âge de " + etat.colons[id].age + ".");
                etat.colons[id]=null;
            }else{
                etat.colons[id].anneesDerniereNaissance++; // Incrémenter les années depuis la dernière naissance
            }
        }
    }


        // Met à jour les colons en les faisant vieillir et en affichant leur état
    void mettreAJourColons(EtatJeu etat) {
        println("\n=== État des Colons ===");
        
        for (int i = 0; i < length(etat.colons); i++) {
            if (etat.colons[i] !=null && etat.colons[i].sante !=0.0) {
                // Faire vieillir le colon et mettre à jour son état
                vieillir(etat,i);
                //satisfactionColon(colon[i]);
            }
        }
        triTableau(etat.colons);
    }


    void triTableau(Colon[] colons){
        for (int i = 1; i < length(colons); i++) {
            Colon current = colons[i];
            if (colons != null) {
                int j = i - 1;

                // Déplace les éléments `null` ou les cases déjà remplies plus loin
                while (j >= 0 && colons[j] == null) {
                    colons[j + 1] = colons[j];
                    j-=1;
                }

                // Place l'élément courant à la bonne position
                colons[j + 1] = current;
            }
        }
    }

    Colon[] incrementationTailleTableau(Colon[] colons,int nombreVivants){
        Colon[] colonsNewTab=new Colon[nombreVivants*2]; //double la taille du tableau pour parer à toute éventualité
        for (int i=0;i<nombreVivants;i++){
            colonsNewTab[i]=colons[i];
        }
        return colonsNewTab;
    }

    // Fonction pour compter le nombre de colons vivants
    int compterColonsVivants(Colon[] colons) {
        int nombreVivants = 0;
        while(nombreVivants<length(colons) && colons[nombreVivants]!=null){
            nombreVivants++;
        }
        return nombreVivants; // Retourner le nombre de colons vivants
    }

//----------------------------------------PARTIE------------------------------------------------------------------------------------------------------------------

    void placerVaisseau(Terrain[] LISTEBATIMENTSPOSSIBLES,EtatJeu etat){
        Terrain vaisseau=LISTEBATIMENTSPOSSIBLES[0];
        println("\n" +ANSI_BOLD + "Choisissez une Position de départ " + ANSI_RESET + "où atterir: ");
        int lig=saisirLigne(length(etat.planete.carte,1));
        int col=saisirColonne(length(etat.planete.carte,2));
        
        placerBatiment(etat,LISTEBATIMENTSPOSSIBLES,lig,col,vaisseau);
    }
    
    // Affiche l'état de la planète, y compris la pollution et les ressources
    void afficherEtat(EtatJeu etat) {
        int nbDecimales = length("" + length(etat.planete.carte, 1)); // Pour aligner les numéros de lignes
        if(etat.tour==0){
            println(ANSI_BOLD + "Carte de la Planète" + ANSI_RESET+"\n");
        }else{
            println(ANSI_BOLD + "Carte de la Planète" + ANSI_RESET+"                                                                     "+ ANSI_BOLD + "Stockage\n");
        }
        
        // En-tête des colonnes (A, B, C, ...)
        print("  ");
        for (int c = 1; c < length(etat.planete.carte, 2); c++) {
            if (c == 1) {
                String espace = "";
                for (int i = 0; i < nbDecimales; i++) {
                    espace += " ";
                }
                print(espace + 'A' + " ");
            } else {
                print(" " + (char) (64 + c) + " ");
            }
        }

        if(etat.tour>0){
            println("    |  "+ANSI_BOLD + "Ressources:"+ ANSI_RESET);
        }else{
            println();
        }
        // Afficher chaque ligne de la carte avec les ressources et des informations à côté
        for (int l = 1; l < length(etat.planete.carte, 1); l++) {
            String affichageL = "" + l;
            while (length(affichageL) < nbDecimales) {
                affichageL = "0" + affichageL;
            }
            affichageL = substring(affichageL, 0, nbDecimales);
            
            print(affichageL + " "); // Numéro de ligne
            for (int c = 1; c < length(etat.planete.carte, 2); c++) {
                String ressource = etat.planete.carte[l][c].symbole;
                String colorCode = getResourceColor(ressource,etat.planete.carte[l][c]);
                print(colorCode + ressource + ANSI_RESET); // Ressources sous forme de grille
            }
            if(etat.tour>0){
                // Ajouter des informations supplémentaires sur la même ligne
                print("    |  "); // Séparation visuelle

                int max=length(etat.ressources[2].nom);
                for(int a=3;a<length(etat.ressources);a++){
                    if (length(etat.ressources[a].nom)>max){
                        max=length(etat.ressources[a].nom);
                    }
                }

                int maxQuant=length(""+etat.ressources[2].quantite);
                for(int b=3;b<length(etat.ressources);b++){
                    if (length(""+etat.ressources[b].quantite)>maxQuant){
                        maxQuant=length(""+etat.ressources[b].quantite);
                    }
                }
                int maxVar=length(""+etat.gestion.variationRessources[2]);
                for(int c=3;c<length(etat.gestion.variationRessources);c++){
                    if (length(""+etat.gestion.variationRessources[c])>maxVar){
                        maxVar=length(""+etat.gestion.variationRessources[c]);
                    }
                }

                if (l>=2 && l < length(etat.ressources)) {
                    String var="";
                    if(etat.gestion.variationRessources[l]>0){
                        var=" (+"+etat.gestion.variationRessources[l]+")";
                    }else if(etat.gestion.variationRessources[l]<0){
                        var=" ("+etat.gestion.variationRessources[l]+")";
                    }

                    println(formatCharacteristic(etat.ressources[l].nom,max) + " : " + formatCharacteristic(""+etat.ressources[l].quantite,maxQuant)+formatCharacteristic(var,maxVar+3));
                    //if (l==6 || l==9){
                        //Essayer éventuellement de mettre un espace entre les res naturelles et le reste (pareil pour l'elec)
                    //}
                    
                    etat.ressources[10]=newRessource("Electricité", "Elec",1.0,150+etat.gestion.variationRessources[10]);
                    etat.gestion.variationRessources[l]=0;
                } else {
                    println();
                }
            }else{
                println();
            }
        }
    }

    Gestion newGestion(Terrain[] RESSOURCESINIT,Terrain[] LISTEBATIMENTSPOSSIBLES){
        Gestion g=new Gestion();
        g.tabMoyennepollution=new double[length(LISTEBATIMENTSPOSSIBLES)];
        return g;
    }

    EtatJeu initialiserNouvellePartie(Terrain[] RESSOURCESINIT,Terrain[] LISTEBATIMENTSPOSSIBLES) {
        // Créer un nouvel état de jeu
        EtatJeu nouvelEtat = new EtatJeu();
        
        //INitialisation du nom de la colonie (fichier de sauvegarde)
        nouvelEtat.nom=readStringSecurise(ANSI_BOLD + "Entrez le nom " + ANSI_RESET + "de votre nouvelle colonie : ") + ".csv";
        // Initialisation du tour à 0
        nouvelEtat.tour = 0;
        
        // Initialisation du score à 0
        nouvelEtat.score = 0.0;

        // Initialisation des ressources disponibles
        nouvelEtat.ressources = RESSOURCESINIT;

        // Création de la planète 
        int largeur = 27;
        int longueur = 27;
        nouvelEtat.planete = newPlanete(nouvelEtat.ressources, longueur, largeur);
        
        // Générer les colons initiaux
        nouvelEtat.colons = genererColons(6); // 6 colons de départ

        // Générer les paramètres initiaux
        nouvelEtat.gestion=newGestion(RESSOURCESINIT,LISTEBATIMENTSPOSSIBLES);

        afficherEtat(nouvelEtat);
        placerVaisseau(LISTEBATIMENTSPOSSIBLES,nouvelEtat);     
        return nouvelEtat;
    }

//---------------------------------------------------------------MENUS-------------------------------------------------------------------------------------------------------------------------

    void afficherMenuPrincipal() {
        println("\n========== MENU PRINCIPAL ==========");
        println("1. Commencer une " + ANSI_BOLD + "nouvelle partie" + ANSI_RESET);
        println("2. "+ ANSI_BOLD + "Charger " + ANSI_RESET + "une ancienne sauvegarde");
        println("3. "+ ANSI_BOLD + "Quitter" + ANSI_RESET);
        println("------------------------------------");
    }

    void afficherMenuJeu() {
        println("\n=== ACTIONS POSSIBLES ===");
        println("1. " + ANSI_BOLD + "Construire" + ANSI_RESET + " un Bâtiment");
        println("2. " + ANSI_BOLD + "Passer" + ANSI_RESET + " cette année");
        println("3. " + ANSI_BOLD + "Sauvegarder" + ANSI_RESET + " la partie");
        println("4. " + ANSI_BOLD + "Quitter" + ANSI_RESET);
        println("-------------------------");
    }

    void menuPlacerBatiment(Terrain[] LISTEBATIMENTSPOSSIBLES, EtatJeu etat){
        println("\n===== CONSTRUIRE =====\n");

        Terrain[] listeBatimentsPosable=new Terrain[length(LISTEBATIMENTSPOSSIBLES)];

        int lig=saisirLigne(length(etat.planete.carte,1));
        int col=saisirColonne(length(etat.planete.carte,2));

        int id=0;
        int cmpt=0;
        while(cmpt<length(LISTEBATIMENTSPOSSIBLES)){
            if(batimentPosable(etat,LISTEBATIMENTSPOSSIBLES,lig,col,LISTEBATIMENTSPOSSIBLES[cmpt])){
                listeBatimentsPosable[id]=LISTEBATIMENTSPOSSIBLES[cmpt];
                id++;
            }
            cmpt++;
        }

        id=1;
        if (TerrainTabIsEmpty(listeBatimentsPosable)){
            println("Vous ne pouvez placer aucun batiment sur cette case !\nVeuillez en saisir une autre");
            menuPlacerBatiment(LISTEBATIMENTSPOSSIBLES,etat);
            return;
        }else{
            println("\nQuel batiment voulez-vous construire sur cette case ?: \n");
            int maxLenRes=0;
            
            for(int c=0;c<length(listeBatimentsPosable);c++){
                if (listeBatimentsPosable[c] != null && length(listeBatimentsPosable[c].nom)>maxLenRes){
                    maxLenRes=length(listeBatimentsPosable[c].nom);
                }
            }

            for(int e=0;e<length(listeBatimentsPosable);e++){
                if(listeBatimentsPosable[e]!=null){
                    String recette="( ";
                    for (int j=0;j<length(listeBatimentsPosable[e].ResNecessaire.coutDeConstruction);j++){
                        recette+=""+listeBatimentsPosable[e].ResNecessaire.quantiteNecessaire[j]+" "+etat.ressources[listeBatimentsPosable[e].ResNecessaire.coutDeConstruction[j]].nom+", ";
                    }
                    recette=substring(recette,0,length(recette)-2)+" )";

                    println(id+" - "+ listeBatimentsPosable[e].symbole + " " +formatCharacteristic(listeBatimentsPosable[e].nom,maxLenRes+1)+recette);
                    id++;
                }
            }
            println("\n"+(id)+" - Ne pas poser de batiment");
        }

        int choix=0;
        do{
            choix = readIntSecurise(ANSI_BOLD + "Choisissez une action" + ANSI_RESET + " (1-"+(id)+") : ");
            if (choix < 1 || choix > id){
                println(ANSI_RED + "Option invalide. Veuillez réessayer." + ANSI_RESET);
            }
        }while(choix < 1 || choix > id);
        int place=0;
        if (choix==id){
            place=1;
        }
        switch (place) {
                case 0:
                    placerBatiment(etat, LISTEBATIMENTSPOSSIBLES,lig,col,listeBatimentsPosable[choix-1]);
                    return;
                case 1:
                    gestionMenuJeu(etat,LISTEBATIMENTSPOSSIBLES);
                    return;
                default:
                    println(ANSI_RED + "Option invalide. Veuillez réessayer." + ANSI_RESET);
        }
    }

    boolean gestionMenuJeu(EtatJeu etatJeu,Terrain[] LISTEBATIMENTSPOSSIBLES) {
        while (true) {
            afficherMenuJeu();
            int choix = readIntSecurise(ANSI_BOLD + "Choisissez une action" + ANSI_RESET + " (1-4) : ");
            
            switch (choix) {
                case 1:
                    menuPlacerBatiment(LISTEBATIMENTSPOSSIBLES,etatJeu);
                    return true;
                case 2:
                    return true; // Passer l'année
                case 3:
                    gestionSauvegarde(etatJeu);
                    return true;
                case 4:
                    return gestionQuitter(etatJeu);
                default:
                    println(ANSI_RED + "Option invalide. Veuillez réessayer." + ANSI_RESET);
            }
        }
    }

    void gestionSauvegarde(EtatJeu etatJeu) {
        String nomFichier=etatJeu.nom;
        println("\n=== OPTIONS DE SAUVEGARDE ===");
        println("1. "+ ANSI_BOLD + "Sauvegarder " + ANSI_RESET + "et continuer");
        println("2. "+ ANSI_BOLD + "Sauvegarder et quitter" + ANSI_RESET);
        println("3. "+ ANSI_BOLD+ "Annuler" + ANSI_RESET);
        
        int choix = readIntSecurise(ANSI_BOLD + "Votre choix : " + ANSI_RESET);
        
        switch (choix) {
            case 1:
                sauvegarderJeu(etatJeu, nomFichier);
                break;
            case 2:
                sauvegarderJeu(etatJeu, nomFichier);
                System.exit(0);
                break;
            case 3:
                return;
            default:
                println(ANSI_RED + "Option invalide." + ANSI_RESET);
        }
    }

    boolean gestionQuitter(EtatJeu etatJeu) {
        String nomFichier=etatJeu.nom;
        println("\n=== QUITTER ===");
        println("1. " + ANSI_BOLD + "Continuer" + ANSI_RESET + " la partie");
        println("2. " + ANSI_BOLD + "Quitter" + ANSI_RESET + " sans sauvegarder");
        println("3. " + ANSI_BOLD + "Sauvegarder et quitter" + ANSI_RESET);
        
        int choix = readIntSecurise(ANSI_BOLD + "Votre choix : " + ANSI_RESET);
        
        switch (choix) {
            case 1:
                return true; // Continuer la partie
            case 2:
                return false; // Terminer la partie sans sauvegarder
            case 3:;
                sauvegarderJeu(etatJeu, nomFichier);
                return false; // Terminer la partie après sauvegarde
            default:
                println(ANSI_RED + "Option invalide." + ANSI_RESET);
                return true;
        }
    }

    EtatJeu gestionMenuPrincipal() {
        while (true) {
            afficherMenuPrincipal();
            int option = readIntSecurise(ANSI_BOLD + "Choisissez une option" + ANSI_RESET + " (1-3) : ");
            
            switch (option) {
                case 1:
                    return initialiserNouvellePartie(RESSOURCESINIT,LISTEBATIMENTSPOSSIBLES);
                case 2:
                    String nomFichier = readStringSecurise(ANSI_BOLD + "Entrez" + ANSI_RESET + " le nom de la colonie : ");
                    EtatJeu etatCharge = chargerJeu(nomFichier);
                    if (etatCharge != null) {
                        return etatCharge;
                    }
                    println(ANSI_BOLD + "Chargement échoué." + ANSI_RESET + " Démarrage d'une nouvelle partie.");
                    return initialiserNouvellePartie(RESSOURCESINIT,LISTEBATIMENTSPOSSIBLES);
                case 3:
                    println(ANSI_BOLD + "Au revoir!" + ANSI_RESET);
                    System.exit(0);
                default:
                    println(ANSI_BOLD + "Option invalide." + ANSI_RESET + " Veuillez réessayer.");
            }
        }
    }

    void afficherResultatFinal(EtatJeu etatJeu) {
        clearScreen();
        println("=== FIN DE LA PARTIE ===");
        println(ANSI_BOLD + "Nombre total" + ANSI_RESET + " de tours : " + etatJeu.tour);
        println(ANSI_BOLD + "Nombre final" + ANSI_RESET + " de colons : " + etatJeu.gestion.nombreVivants);
    }

//-------------------------------------------------------VOID ALGORITHM()-----------------------------------------------------------------------------------------
    // Fonction principale de l'algorithme du jeu
    void algorithm() {
        final String FILENAME = "../../../ressources/CSV-TXT/ASCII-art.txt";
        extensions.File f = newFile(FILENAME);
        int nbLines = 0;
        while(ready(f)){
            String currentLine = readLine(f);
            nbLines++;
            println(currentLine);
        }
        
        EtatJeu etatJeu = gestionMenuPrincipal();

        boolean partieTerminee = false;
        
        while (!partieTerminee) {
            // Incrémentation du tour
            etatJeu.tour++;
            etatJeu.planete.pollution= pollutionTotale(etatJeu.planete.pollution,etatJeu.gestion.tabMoyennepollution);
            
            clearScreen();
            println("\n=== Année " + etatJeu.tour + " ===");

            // Affichage de l'état actuel
            afficherEtat(etatJeu);
            
            mettreAJourBatiment(etatJeu,LISTEBATIMENTSPOSSIBLES);
            mettreAJourColons(etatJeu);

            // Gestion de la population
            etatJeu.gestion.nombreVivants = compterColonsVivants(etatJeu.colons);
            
            // Expansion du tableau de colons si population stable
            if ((double) etatJeu.gestion.nombreVivants / (double) length(etatJeu.colons) > 0.70) {
                etatJeu.colons = incrementationTailleTableau(etatJeu.colons, etatJeu.gestion.nombreVivants);
            }

            // Reproduction des colons
            for(int i = 0; i < etatJeu.gestion.nombreVivants; i++){
                if (random() < PROBABILITE_REPRODUCTION) {
                    etatJeu.colons = reproduire(etatJeu.colons, etatJeu.gestion);
                    etatJeu.gestion.nombreVivants = compterColonsVivants(etatJeu.colons);
                }
            }

                        // Vérification des conditions de fin de partie
            if (etatJeu.gestion.nombreVivants <= 0) {
                partieTerminee = true;
            }else{
                etatJeu.gestion.nombreVivants = compterColonsVivants(etatJeu.colons);
                println("\n" + ANSI_BOLD + "Nombre de colons survivants : "+ ANSI_RESET + etatJeu.gestion.nombreVivants);
    
                // etatJeu.score = calculerScore(nombreVivants, etatJeu.planete, etatJeu.ressources);
    
                // Menu de jeu
                boolean continuerTour = gestionMenuJeu(etatJeu,LISTEBATIMENTSPOSSIBLES);
                if (!continuerTour) {
                    partieTerminee=true;
                }
    
                println("\n-----------------------\n");
            }
        }
        afficherResultatFinal(etatJeu);
    }
}
