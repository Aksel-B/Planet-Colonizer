class CaseCarte{
    String symbole;
    int quantiteRestante;
    Terrain ressourceActuelle;
    Terrain ressourceCaseInit;
    boolean exploitee;
}