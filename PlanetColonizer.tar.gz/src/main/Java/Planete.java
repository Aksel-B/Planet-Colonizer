class Planete{
    double pollution;                 // Niveau de pollution global
    CaseCarte[][] carte;
}