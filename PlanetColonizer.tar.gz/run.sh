#!/bin/bash

# Naviguer dans le dossier contenant les classes
cd ./src/main/Class || { echo "Le dossier 'Class' est introuvable."; exit 1; }

# Vérifier si la classe principale existe
if [ ! -f PlanetColonizer.class ]; then
  echo "Erreur : La classe PlanetColonizer.class est introuvable."
  exit 1
fi

# Exécuter le programme
echo "Exécution de PlanetColonizer..."
sleep 1
clear
java -cp ../program.jar:. PlanetColonizer
